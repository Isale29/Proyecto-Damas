#include <iostream>
#include "Ctablero.h"
int main() {
    Ctablero obj1(9,9);
    obj1.dibujar_tablero();
    obj1.imprimir_tablero();
    return 0;
}
