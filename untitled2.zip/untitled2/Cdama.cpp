//
// Created by LENOVO on 29/06/2022.
//

#include "Cdama.h"

string Cdama::setcolor() {
    return color;
}