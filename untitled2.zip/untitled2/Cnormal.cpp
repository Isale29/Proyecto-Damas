//
// Created by LENOVO on 29/06/2022.
//

#include "Cnormal.h"

int Cnormal::movimiento_x() {
    int nx=x;
    //cout<<"Ingrese nueva coordenada en x: ";cin>>nx;
    return nx;
}

int Cnormal::movimiento_y() {
    int ny=y;
    //cout<<"Ingrese nueva coordenada en x: ";cin>>ny;
    return ny;

}